export class Fox
{
    constructor(x, y, speed, width, height, canvas, ctx, max_movement, type)
    {
        this.x = x;
        this.y = y;
        this.defX = x;
        this.defY = y;
        this.speed = speed;
        this.canvas = canvas;
        this.width = width;
        this.height = height;
        this.max_movement = max_movement;
        this.ctx = ctx;
        this.type = type;
        this.foxImages = this.loadAnim("n");
        this.foxFlipImages = this.loadAnim("f");
        this.foxDeadImage = new Image();
        this.foxDeadImage.src = "src/img/enemy/fox/normal/dead_fox.png";
        this.currentImage = this.foxImages[0];
        this.frameIndex = 0;
        this.frameCounter = 0;
        this.moveDirection = "left";
        this.die = false;
        this.deadY = y - 40;
        this.down = false;
    }

    loadAnim(type)
    {
        let images = [];
        for(let i = 0; i < 8; ++i)
        {
            const kep = new Image();
            if(type == "n") kep.src = `src/img/enemy/fox/normal/fox${i}.png`;
            else kep.src = `src/img/enemy/fox/flip/fox${i}.png`;
            images.push(kep);
        }
        return images;
    }

    collide(rect)
    {
        const enemyTop = this.y;
        const enemyBottom = this.y + this.height;
        const enemyLeft = this.x;
        const enemyRight = this.x + this.width;

        const rectTop = rect.y;
        const rectBottom = rect.y + rect.height;
        const rectLeft = rect.x;
        const rectRight = rect.x + rect.width;

        if(enemyLeft >= rectRight) return false;
        if(enemyRight <= rectLeft) return false;
        if(enemyTop >= rectBottom) return false;
        if(enemyBottom <= rectTop) return false;
        return true;
    }

    collideWithPoops(poops)
    {
        if(poops.length > 0)
        {
            let index = 0;
            for(const poop of poops)
            {
                if(this.collide(poop))
                {
                    poops.splice(index, 1);
                    this.die = true;                
                }
                ++index;
            }
        }

    }

    animate()
    {
        
        if(!this.die)
        {
            if(this.frameCounter > 10)
                {
                    if(this.frameIndex > (this.foxImages.length - 2)) this.frameIndex = 0;
                    else ++this.frameIndex;
                    if(this.moveDirection == "left") this.currentImage = this.foxImages[this.frameIndex];
                    else this.currentImage = this.foxFlipImages[this.frameIndex];
                    this.frameCounter = 0;
                }
                else ++this.frameCounter;
        }
        else
        {
            this.currentImage = this.foxDeadImage;
        }
    }

    move()
    {
        if(!this.die)
        {
            if(this.moveDirection == "left" && this.x > (this.defX - this.max_movement)) this.x -= this.speed;
            else this.moveDirection = "right";
            if(this.moveDirection == "right" && this.x < (this.defX + this.max_movement)) this.x += this.speed;
            else this.moveDirection = "left";
        }
        else
        {
            if(this.y > this.deadY && !this.down)
            {
                this.y -= 10;
                
            }
            else this.down = true;
            if(this.down)
            {
                this.y += 4;
            }
        }
        if(this.die && this.down && this.y > (480 + this.defY)) this.type = "dead";
    }

    draw(scrollX, scrollY)
    {
        this.animate();
        this.ctx.drawImage(this.currentImage, this.x - scrollX, this.y - scrollY, this.width, this.height);
        this.move();
    }

    update(poops)
    {
        this.collideWithPoops(poops);
    }
}