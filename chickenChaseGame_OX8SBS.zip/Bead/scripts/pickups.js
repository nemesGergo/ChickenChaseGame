export class PickUp
{
    constructor(x, y, width, height, type, score, ctx)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.type = type;
        this.score = score;
        this.ctx = ctx;
        this.pickUpImages = { corn: this.loadImage("src/img/objects/pickups/corn.png"), heal: this.loadImage("src/img/objects/pickups/health.png"), lives: this.loadImage("src/img/objects/pickups/egg.png")};
    }
    loadImage(path)
    {
        const img = new Image();
        img.src = path;
        return img; 
    }
    draw(scrollX, scrollY)
    {
        this.ctx.drawImage(this.pickUpImages[this.type], this.x - scrollX, this.y - scrollY, this.width, this.height);
    }
}