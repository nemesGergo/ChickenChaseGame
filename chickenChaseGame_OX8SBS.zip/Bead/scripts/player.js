export class Player
{
    constructor(x, y, width, height, speed, lives, health, ctx, canvas)
    {
        this.x = x;
        this.y = y;
        this.x_vel = 0;
        this.y_vel = 0;
        this.spawnX = x;
        this.spawnY = y;
        this.airTimer = 0;
        this.playerScrollX = 305;
        this.playerScrollY = 223;
        this.flip = false;
        this.isMoving = false;
        this.isGround = false;
        this.isHurting = false;
        this.hurtCount = 0;
        this.dying = false;
        this.fallingDown = false;
        this.deadY = 0;
        this.readyToSpawn = false;
        this.outOfLives = false;
        this.isGameFinished = false;

        this.lives = lives;
        this.health = health;
        this.highScore = 0;
        this.collectedCorns = 0;

        this.width = width;
        this.height = height;

        this.playerYMomentum = 0;

        this.speed = speed
        this.ctx = ctx
        this.canvas = canvas
        this.playerImg = new Image();
        this.playerImg.src = 'src/img/csirke.png';
        
        this.playerImgFlip = new Image();
        this.playerImgFlip.src = "src/img/csirke_flip.png";
        this.frameIndex = 0;
        this.frameCount = 0;

        this.poops = [];
        this.poopCounter = 0;

        this.playerAnimImages = 
        {
            idle: [this.loadImage('src/img/player/normal/idle/idle.png')],
            walk: [this.loadImage("src/img/player/normal/walk/walk0.png"), this.loadImage("src/img/player/normal/walk/walk1.png"), this.loadImage("src/img/player/normal/walk/walk2.png")],
            fly:  [this.loadImage("src/img/player/normal/fly/fly0.png"), this.loadImage("src/img/player/normal/fly/fly1.png"), this.loadImage("src/img/player/normal/fly/fly2.png")],
            die:  [this.loadImage("src/img/player/normal/die/die.png")]
        };
        this.playerFlipAnimImages = 
        {
            idle: [this.loadImage('src/img/player/flip/idle/idle.png')],
            walk: [this.loadImage("src/img/player/flip/walk/walk0.png"), this.loadImage("src/img/player/flip/walk/walk1.png"), this.loadImage("src/img/player/flip/walk/walk2.png")],
            fly:  [this.loadImage("src/img/player/flip/fly/fly0.png"), this.loadImage("src/img/player/flip/fly/fly1.png"), this.loadImage("src/img/player/flip/fly/fly2.png")],
            die:  [this.loadImage("src/img/player/normal/die/die.png")]
        };
        this.animCounts = {
            idle: 1,
            walk: 2,
            fly:  2,
            die: 1
        };
        this.jumpSound = new Audio("src/au/eff/player/jump.mp3");
        this.jumpSound.volume = 0.1;
        this.eatSound = new Audio("src/au/eff/player/eat.mp3");
        this.hurtSound = new Audio("src/au/eff/player/hurt.mp3");
        this.livesCollectSound = new Audio("src/au/eff/player/collectLives.mp3");
        this.dieSoundEffect = new Audio("src/au/eff/player/lose.mp3");
        this.poopSoundEffect = new Audio("src/au/eff/player/fall.mp3");
        this.playerState = "idle";

        window.addEventListener("keydown", this.handleKeys.bind(this));
        window.addEventListener("keyup", this.handleRelaseKeys.bind(this));
    }

    entitiesCollosionDetection(entities, spawnpoints)
    {
        for(const spawnpoint of spawnpoints)
        {
            if(this.collide(spawnpoint))
            {
                if(spawnpoint.state == "unused")
                {
                    this.spawnX = spawnpoint.x;
                    this.spawnY = spawnpoint.y - 5;
                    spawnpoint.state = "used";
                }
            }
        }
        for(const type of entities)
        {
            for(const entity of type)
            {
                if(this.collide(entity)) this.processTheEntityCollide(entity);
            }
        }
    }

    processGameEnd(end_table)
    {
        if(this.collide(end_table))
        {
            this.isGameFinished = true;
        }
    }

    processTheEntityCollide(entity)
    {
        switch(entity.type)
        {
            case "fox":
                if(entity.die != true) this.hurt();
                break;
            case "corn":
                entity.type = "collected";
                this.highScore += entity.score;
                ++this.collectedCorns;
                this.eatSound.play();
                break;
            case "heal":
                entity.type = "collected";
                this.highScore += entity.score;
                this.eatSound.play();
                this.heal();
                break;
            case "lives":
                entity.type = "collected";
                this.highScore += entity.score;
                this.addLives(1);
                this.livesCollectSound.play();
                break;
        }
    }

    hurt()
    {
        if(!this.isHurting)
        {
                this.hurtSound.play();
                this.isHurting = true;
                this.health -= 20;
                this.playerYMomentum = -7;
                if(this.health == 0)this.die();
        }
    }

    die()
    {
        if(!this.dying)
        {
            this.dieSoundEffect.play();
            this.deadY = this.y;
            this.dying = true;
        }
        if(this.readyToSpawn)
        {
            this.dying = false;
            --this.lives;
            this.respawn();
            this.readyToSpawn = false;
            this.fallingDown = false;
        }
    }

    respawn()
    {
        if(this.lives > 0)
        {
            this.x = this.spawnX;
            this.y = this.spawnY;
            this.health = 100;
        }
        else this.outOfLives = true;
    }

    heal()
    {
        if(this.health + 20 < 100) this.health += 20;
        else this.health = 100;
    }

    addLives(count) {this.lives += count;}

    shoot()
    {
        if(!this.isGround && this.poopCounter == 0)
        {
            this.poopSoundEffect.play();
            this.poopCounter = 20;
            this.poops.push(new Poop(this.x, this.y, 14, 17, this.ctx));
        }
    }

    update(tile_rects, entities, spawnpoints, scrollX, scrollY, end_table)
    {
        if(this.isHurting && this.hurtCount < 100) ++this.hurtCount
        else
        {
            this.isHurting = false;
            this.hurtCount = 0;
        }
        for(let i = 0; i < this.poops.length; ++i) this.poops[i].update(scrollX, scrollY, tile_rects, i, this.poops);
        this.changePlayerState();
        this.animate();
        this.move(tile_rects);
        this.processGameEnd(end_table);
        if(!this.dying) this.entitiesCollosionDetection(entities, spawnpoints);
        this.draw(scrollX, scrollY);
        if(this.poopCounter > 0) --this.poopCounter;
    }

    move(tile_rects)
    {
        if(!this.dying)
        {
            this.y_vel = 0;
            this.y_vel += this.playerYMomentum;
            this.playerYMomentum += 0.25;
            if(this.playerYMomentum > 3) this.playerYMomentum = 3;
    
            this.x += this.x_vel;
            let hitList = this.checkCollosions(tile_rects);
            for(const tile of hitList)
            {
                if(this.x_vel > 0) this.x = tile.x - this.width;
                else if(this.x_vel < 0) this.x = tile.x + tile.width;
            }
    
            hitList = [];
            
            this.y += this.y_vel;
            hitList = this.checkCollosions(tile_rects);
            this.isGround = false;
            for(const tile of hitList)
            {
                if(this.y_vel > 0) this.y = tile.y - this.height;
                else if(this.y_vel < 0) this.y = tile.y + tile.height;
                this.isGround = true;
            }
    
            if(this.isGround)
            {
                this.airTimer = 0;
                this.playerYMomentum = 0;
            }
            else ++this.airTimer;
        }
        else
        {
            if(this.y > (this.deadY - 50) && !this.fallingDown) this.y -= 5;
            else this.fallingDown = true;
            if(this.fallingDown) this.y += 5;
            if(this.fallingDown && (this.y > (this.deadY + 480)))
            {
                this.readyToSpawn = true;
                this.die();
            }
        }
    }

    loadImage(path)
    {
        const img = new Image();
        img.src = path;
        return img;
    }

    changePlayerState()
    {
        if(this.isMoving && this.airTimer <= 1 && this.airTimer >= 0) this.playerState = "walk";
        else if(this.airTimer > 1) this.playerState = "fly";
        else this.playerState = "idle";
    }

    animate()
    {
        if(!this.dying)
        {
            if(this.playerState == "idle")
                {
                    if(!this.flip) this.playerImg = this.playerAnimImages[this.playerState][0];
                    else this.playerImg = this.playerFlipAnimImages[this.playerState][0];
                }
                else
                {
                    if(this.frameCount >= 12)
                    {   
                        if(this.frameIndex === this.animCounts[this.playerState]) this.frameIndex = 0;
                        else ++this.frameIndex;
                        if(!this.flip) this.playerImg = this.playerAnimImages[this.playerState][this.frameIndex];
                        else this.playerImg = this.playerFlipAnimImages[this.playerState][this.frameIndex];
                        this.frameCount = 0;
                    }
                    else this.frameCount++;   
                }
        }
        else
        {
            if(!this.readyToSpawn) this.playerImg = this.playerAnimImages["die"][0];
            else this.playerImg = this.playerAnimImages["idle"][0];
        }
    }

    draw(scrollX, scrollY)
    {
        this.ctx.drawImage(this.playerImg, this.x - scrollX, this.y - scrollY, this.width, this.height);
    }

    collide(rect)
    {
        const playerTop = this.y;
        const playerBottom = this.y + this.height;
        const playerLeft = this.x;
        const playerRight = this.x + this.width;

        const rectTop = rect.y;
        const rectBottom = rect.y + rect.height;
        const rectLeft = rect.x;
        const rectRight = rect.x + rect.width;

        if(playerLeft >= rectRight) return false;
        if(playerRight <= rectLeft) return false;
        if(playerTop >= rectBottom) return false;
        if(playerBottom <= rectTop) return false;
        return true;
    }

    checkCollosions(tile_rects)
    {
        let hitList = [];
        for(const tile of tile_rects) if(this.collide(tile)) hitList.push(tile);
        return hitList;
    }

    handleKeys(key)
    {
        
        switch(key.key)
        {
            case "a":
                this.x_vel = -this.speed;
                this.flip = true;
                this.isMoving = true;
                break;
            case "d":
                this.x_vel = this.speed;
                this.flip = false;
                this.isMoving = true;
                break;
            case "w":
                this.y_vel = -this.speed;
                break;
            case "s":
                this.y_vel = this.speed;
                break;
            case " ":
                if(this.airTimer < 6)
                {
                    this.jumpSound.play();
                    this.playerYMomentum = -7;
                }
                break;
            case "v":
                if(this.airTimer > 1) this.shoot();
                break;
        }
    }

    handleRelaseKeys(key)
    {
        switch(key.key)
        {
            case "a":
                this.x_vel = 0;
                this.isMoving = false;
                break;
            case "d":
                this.x_vel = 0;
                this.isMoving = false;
                break;
            case "w":
                this.y_vel = 0;
                break;
            case "s":
                this.y_vel = 0;
                break;
        }
    }
}

export class Poop
{
    constructor(x, y, width, height, ctx)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.ctx = ctx;
        this.image = new Image();
        this.image.src = "src/img/objects/secretweapon/poop.png";
    }

    update(scrollX, scrollY, tileMap, index, poopList)
    {
        this.y += 5;
        this.draw(scrollX, scrollY);
        this.collideWithTheTilemap(tileMap, index, poopList);
    }

    collideWithTheTilemap(tileMap, index, poopList)
    {
        for(const tile of tileMap)
        {
            if(this.collide(tile)) poopList.splice(index, 1);
        }
    }

    collide(rect)
    {
        const poopTop = this.y;
        const poopBottom = this.y + this.height;
        const poopLeft = this.x;
        const poopRight = this.x + this.width;

        const rectTop = rect.y;
        const rectBottom = rect.y + rect.height;
        const rectLeft = rect.x;
        const rectRight = rect.x + rect.width;

        if(poopLeft >= rectRight) return false;
        if(poopRight <= rectLeft) return false;
        if(poopTop >= rectBottom) return false;
        if(poopBottom <= rectTop) return false;
        return true;
    }

    draw(scrollX, scrollY)
    {
        this.ctx.drawImage(this.image, this.x - scrollX, this.y - scrollY, this.width, this.height);
    }

}