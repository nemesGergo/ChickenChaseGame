export class SpawnPoint
{
    constructor(x, y, width, height, ctx)
    {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.state = "unused";
        this.ctx = ctx;
        this.images = this.loadAnim();
        this.image = this.images[0];
        this.frameIndex = 0;
        this.frameCount = 0;
    }

    loadAnim()
    {
        let imgTemp = [];
        for(let i = 0; i < 6; ++i) imgTemp.push(this.loadImage(`src/img/objects/spawnpoint/nest${i}.png`));
        return imgTemp;
    }

    loadImage(path)
    {
        const img = new Image();
        img.src = path;
        return img;
    }

    animate()
    {
        
        if(this.frameCount >= 12)
        {
            ++this.frameIndex;
            this.image = this.images[this.frameIndex];
            this.frameCount = 0;
        }
        else this.frameCount++;
    }

    draw(scrollX, scrollY)
    {
        if(this.state == "used" && this.frameIndex < (this.images.length - 1)) this.animate();
        this.ctx.drawImage(this.image, this.x - scrollX, this.y - scrollY, this.width, this.height);
    }

}